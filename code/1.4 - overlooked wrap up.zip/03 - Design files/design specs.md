# Week 1 wrap up

## Colors

### Neutral

- base: #5e5e5e;
- darker: #494949;

### UI

- ui light: #f8e2ff;
- ui dark: #580d3a;

### UX

- ux light: #e2ffea;
- ux dark: #115926;

### Dev

- dev light: #e2fcff;
- dev dark: #024f4f;

---

## Typography

- Font family: Podkova, Open Sans
- Podkova bold
- Open Sans Regular, Bold

### Font sizes

- Name: 36px
- Body: 16px
- Roles: 12px