# Design Specifications | Magic site v2

## Colors

- Neutral Dark: #171717
- Neutral white: #fff
- Accent: #59E89C

## Typogrpahy

### Font family

- PT Sans
- weights: 400 + 700

### Font sizes

- h1: 36px

- h2: 36px

- h3: 24px

- p: 18px

  